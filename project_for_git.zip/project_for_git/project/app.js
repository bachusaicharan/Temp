const express = require("express");
const fs = require("fs");
const app = express();
const PORT = 3000;
app.use(express.static("public"));
app.get("/hello", (req, res) => {
  const userMessage = req.query.message || "Hello World";
  const output = { message: userMessage };
  fs.writeFileSync("data.json", JSON.stringify(output, null, 2));
  res.send(userMessage);
});
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});